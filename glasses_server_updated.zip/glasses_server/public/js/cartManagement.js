
// Add to cart functionality
const addToCart = async (productId, quantity = 1) => {
    const userId = localStorage.getItem('userId');
    try {
        const response = await fetch(`/api/users/${userId}/cart`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ product_id: productId, quantity }),
        });
        if (!response.ok) {
            throw new Error(`Error adding to cart: ${response.statusText}`);
        }
        const cart = await response.json();
        updateCartDisplay(cart); // Update cart display after adding
    } catch (error) {
        console.error('Failed to add to cart:', error);
    }
};

// Update item quantity in cart
const updateCartItem = async (productId, quantity) => {
    const userId = localStorage.getItem('userId');
    try {
        const response = await fetch(`/api/users/${userId}/cart/${productId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ quantity }),
        });
        if (!response.ok) {
            throw new Error(`Error updating cart: ${response.statusText}`);
        }
        const cart = await response.json();
        updateCartDisplay(cart); // Refresh cart display after update
    } catch (error) {
        console.error('Failed to update cart:', error);
    }
};

// Remove item from cart
const removeFromCart = async (productId) => {
    const userId = localStorage.getItem('userId');
    try {
        const response = await fetch(`/api/users/${userId}/cart/${productId}`, {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' },
        });
        if (!response.ok) {
            throw new Error(`Error removing from cart: ${response.statusText}`);
        }
        const cart = await response.json();
        updateCartDisplay(cart); // Refresh cart display after removal
    } catch (error) {
        console.error('Failed to remove from cart:', error);
    }
};

// Function to update cart display on the webpage
const updateCartDisplay = (cart) => {
    const cartElement = document.getElementById('cart-items');
    cartElement.innerHTML = ''; // Clear current cart items
    cart.forEach(item => {
        cartElement.innerHTML += `<div>${item.name} - ${item.quantity} x ${item.price}</div>`;
    });
};
