
// Function to list all orders
const listOrders = async () => {
    try {
        const response = await fetch('/api/orders/list', { method: 'GET' });
        if (!response.ok) throw new Error('Failed to fetch orders');
        return await response.json();
    } catch (error) {
        console.error('Error listing orders:', error);
    }
};

// Function to view a specific order
const viewOrder = async (userId, orderId) => {
    try {
        const response = await fetch(`/api/orders/${userId}/${orderId}`, { method: 'GET' });
        if (!response.ok) throw new Error('Failed to fetch order details');
        return await response.json();
    } catch (error) {
        console.error('Error viewing order:', error);
    }
};

// Function to apply discount to an order
const applyDiscount = async (userId, orderId, discountCode) => {
    try {
        const response = await fetch(`/api/orders/${userId}/${orderId}/apply-discount`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ discountCode })
        });
        if (!response.ok) throw new Error('Failed to apply discount');
        return await response.json();
    } catch (error) {
        console.error('Error applying discount:', error);
    }
};

// Function to view order history for a user
const viewOrderHistory = async (userId) => {
    try {
        const response = await fetch(`/api/orders/user/${userId}/history`, { method: 'GET' });
        if (!response.ok) throw new Error('Failed to fetch order history');
        return await response.json();
    } catch (error) {
        console.error('Error viewing order history:', error);
    }
};

// Function to cancel an order
const cancelOrder = async (userId, orderId) => {
    try {
        const response = await fetch(`/api/orders/${userId}/${orderId}/cancel`, { method: 'POST' });
        if (!response.ok) throw new Error('Failed to cancel order');
        return await response.json();
    } catch (error) {
        console.error('Error cancelling order:', error);
    }
};

// Function to update order status
const updateOrderStatus = async (userId, orderId, newStatus) => {
    try {
        const response = await fetch(`/api/orders/${userId}/status`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ orderId, newStatus })
        });
        if (!response.ok) throw new Error('Failed to update order status');
        return await response.json();
    } catch (error) {
        console.error('Error updating order status:', error);
    }
};
