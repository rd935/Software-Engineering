const { createProxyMiddleware } = require('http-proxy-middleware');

module.exports = {
  root: 'public', // Serve the 'public' directory
  proxy: [
    {
      path: '/api/**',
      target: 'http://localhost:3000',
      secure: false,
      changeOrigin: true,
    },
  ],
};
